core.register_on_player_receive_fields(function(player, formname, fields)
    if formname == "" and fields.toggle_skin then
        local name = player:get_player_name()

        if is_crystal[name] then
            if skins and skins.set_player_skin then
                skins.set_player_skin(player, skins.default_skin or "character")
            end
            is_crystal[name] = false
        else
            if skins and skins.set_player_skin then
                skins.set_player_skin(player, "crystalskin")
            end
            is_crystal[name] = true
        end
    end
end)